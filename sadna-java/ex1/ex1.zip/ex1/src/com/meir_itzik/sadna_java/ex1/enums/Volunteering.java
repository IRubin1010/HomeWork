package com.meir_itzik.sadna_java.ex1.enums;

public enum Volunteering {
    SPIRITUAL,
    PHYSICAL,
    MUSICAL
}
